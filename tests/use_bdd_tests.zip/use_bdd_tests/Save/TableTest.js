
var target = UIATarget.localTarget();

UIALogger.logStart("Starting foo");
target.frontMostApp().mainWindow().tableViews()["Empty list"].cells()[0].logElementTree();

element = target.frontMostApp().mainWindow().tableViews()["Empty list"].cells()[0].elements()['textFieldId']
if (element instanceof UIAElementNil) {
	UIALogger.logFail('Failed to find element textFieldId');
} else UIALogger.logDebug('found element '+element);

value = target.frontMostApp().mainWindow().tableViews()["Empty list"].cells()[0].staticTexts()[0].value()
if (!value || value.length == 0) {
	UIALogger.logFail('Failed to find celllabel');	
}
target.frontMostApp().mainWindow().tableViews()["Empty list"].cells()[0].tap();
target.frontMostApp().mainWindow().tableViews()["Empty list"].cells()[1].tap();
target.frontMostApp().mainWindow().tableViews()["Empty list"].cells()[2].staticTexts()[0].scrollToVisible();
target.frontMostApp().mainWindow().tableViews()["Empty list"].cells()[8].tap();
UIALogger.logFail("Failed foo.");
target.captureScreenWithName("failure.png")
UIALogger.logStart("Starting Success Test")
target.frontMostApp().mainWindow().tableViews()["Empty list"].cells()[0].scrollToVisible();
UIALogger.logPass("Pass Success Test")
