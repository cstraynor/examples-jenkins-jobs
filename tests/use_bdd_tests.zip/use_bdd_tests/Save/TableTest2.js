
var target = UIATarget.localTarget();

UIALogger.logStart("First Test");
element = target.frontMostApp().mainWindow().tableViews()["Empty list"].cells()[0].elements()['textFieldId']
if (element instanceof UIAElementNil) {
	UIALogger.logFail('Failed to find element textFieldId');
} else UIALogger.logDebug('found element '+element);
